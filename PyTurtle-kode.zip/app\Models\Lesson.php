<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lesson extends Model
{
    protected $fillable = ['id', 'title', 'command', 'description', 'example', 'explanation', 'practice_level', 'matching_pairs'];

    protected function casts(): array
    {
        return ['matching_pairs' => 'array'];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
