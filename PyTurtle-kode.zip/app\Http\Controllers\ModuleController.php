<?php

namespace App\Http\Controllers;

use App\Models\Lesson;
use App\Models\User;
use App\Services\GameProgressService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ModuleController extends Controller
{
    public function index(Request $r)
    {
        return view('modules.index', ['lessons' => Lesson::orderBy('id')->get(), 'done' => $r->user()->lessons()->pluck('lessons.id')->all()]);
    }

    public function show(Lesson $module)
    {
        return view('modules.show', ['lesson' => $module]);
    }

    public function complete(Request $r, Lesson $module, GameProgressService $service)
    {
        DB::transaction(function () use ($r, $module, $service) {
            $u = User::whereKey($r->user()->id)->lockForUpdate()->firstOrFail();
            $u->lessons()->syncWithoutDetaching([$module->id]);
            $service->syncXp($u);
        });

        return back()->with('status', 'Materi selesai! +20 XP untuk penyelesaian pertama.');
    }
}
