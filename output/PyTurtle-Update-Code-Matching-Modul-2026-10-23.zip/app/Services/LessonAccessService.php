<?php

namespace App\Services;

use App\Models\Lesson;
use App\Models\User;

class LessonAccessService
{
    /** A lesson opens only when every earlier lesson has been completed. */
    public function unlockedIds(array $orderedIds, array $completedIds): array
    {
        $completed = array_fill_keys(array_map('intval', $completedIds), true);
        $unlocked = [];
        foreach ($orderedIds as $id) {
            $id = (int) $id;
            $unlocked[] = $id;
            if (! isset($completed[$id])) {
                break;
            }
        }

        return $unlocked;
    }

    public function forUser(User $user): array
    {
        $lessons = Lesson::turtleBasics()->learningOrder()->get();
        $done = array_map('intval', $user->lessons()->turtleBasics()->pluck('lessons.id')->all());

        return [
            'lessons' => $lessons,
            'done' => $done,
            'unlocked' => $this->unlockedIds($lessons->pluck('id')->all(), $done),
            'requiredLesson' => $lessons->first(fn (Lesson $lesson) => ! in_array($lesson->id, $done, true)),
        ];
    }

    public function completedCount(User $user): int
    {
        $progress = $this->forUser($user);
        $count = 0;
        foreach ($progress['lessons'] as $lesson) {
            if (! in_array($lesson->id, $progress['done'], true)) {
                break;
            }
            $count++;
        }

        return $count;
    }

    public function requiredForMaze(int $level): int
    {
        return $level <= 2 ? 4 : ($level === 3 ? 8 : 11);
    }

    public function mazeAllowed(User $user, int $level): bool
    {
        return $level >= 1 && $level <= 5 && $this->completedCount($user) >= $this->requiredForMaze($level);
    }

    public function mazeMessage(int $level): string
    {
        return 'Maze Quest level '.$level.' terkunci. Baca dan selesaikan evaluasi materi sampai modul '.$this->requiredForMaze($level).' terlebih dahulu.';
    }

    public function newlyUnlocked(int $before, int $after): array
    {
        $features = [];
        foreach ([4 => ['Maze Quest level 1–2'], 8 => ['Maze Quest level 3'], 11 => ['Maze Quest level 4–5']] as $threshold => $names) {
            if ($before < $threshold && $after >= $threshold) {
                $features = array_merge($features, $names);
            }
        }

        return $features;
    }

    public function lockMessage(?Lesson $requiredLesson): string
    {
        return $requiredLesson
            ? 'Materi masih terkunci. Selesaikan materi '.sprintf('%02d', $requiredLesson->sort_order).' — '.$requiredLesson->title.' terlebih dahulu.'
            : 'Materi masih terkunci. Selesaikan materi sebelumnya terlebih dahulu.';
    }

    public function assertAccessible(User $user, Lesson $module): void
    {
        $progress = $this->forUser($user);
        // Legacy lessons keep their existing access behavior.
        if ($progress['lessons']->contains('id', $module->id)) {
            abort_unless(in_array($module->id, $progress['unlocked'], true), 403, $this->lockMessage($progress['requiredLesson']));
        }
    }
}
